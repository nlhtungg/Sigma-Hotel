const sqlConfig = {
    server: 'DESKTOP-256OKAM\\SQLEXPRESS',
    database: 'SigmaHotel',
    user: 'TungSQLUsername',
    password: '892678',
    Option: {
        trustedConnection: true
    }
};

module.exports = sqlConfig;
