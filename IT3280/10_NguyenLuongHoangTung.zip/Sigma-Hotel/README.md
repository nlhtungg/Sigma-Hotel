throughout heaven and earth i alone am the chosen one
